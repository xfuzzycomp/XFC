# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from sample_trainer import TrainTAS
from kessler_game import TrainerEnvironment


class TASTrain(FitnessCPU):
    """
    Fitness class that defines our ChromosomeBlueprint for eve and provides an evaluate function to analyze the
    asteroid-smashers ai and give it a score
    """
    def __init__(self):
        super().__init__()

        # Define the blueprint for how Eve Chromosomes are structured
        blueprints = [
            # sa
            GeneBlueprint(name="tti_norm_threshold", alleles=[20], shape=[3], kind=GeneKind.repeating),
            GeneBlueprint(name="ast_num_norm_threshold", alleles=[20], shape=[3], kind=GeneKind.repeating),
            GeneBlueprint(name="velocity_norm_threshold", alleles=[10], shape=[3], kind=GeneKind.repeating),
            GeneBlueprint(name="distance_norm_threshold", alleles=[10], shape=[3], kind=GeneKind.repeating),

            # strategies
            FisBlueprint(FisSettings(name="defensive_score_fis", shape=(5, 5), train_centers=TrainCenters.off, input_range=(-1, 1), output_range=(-1, 1), precision=0.10)),
            FisBlueprint(FisSettings(name="aggressive_score_fis", shape=(5, 5), train_centers=TrainCenters.off, input_range=(-1, 1), output_range=(-1, 1), precision=0.10)),

            # aiming
            FisBlueprint(FisSettings(name="aiming_fis", shape=(5, 5), train_centers=TrainCenters.off, input_range=(-1, 1), output_range=(-1, 1), precision=0.05)),

            # firing
            FisBlueprint(FisSettings(name="fire_bid_fis", shape=(5, 5), train_centers=TrainCenters.off, input_range=(-1, 1), output_range=(-1, 1), precision=0.05)),
        ]

        self.chromosome_blueprint = ChromosomeBlueprint(blueprints)

    def evaluate(self, chromosome):
        """
        The evaluate function instantiates a game object and calls our Trainer class
        to evaluate the chromosome across our training portfolio.
        """
        game = TrainerEnvironment()
        return TrainTAS().evaluate_scenarios(chromosome, game)


if __name__ == '__main__':

    # Utilize the following to save off the hero and planet each generation
    file_name = 'trained_planets/TAS_sample'

    #  Define our fitness class object and settings for our planet. Changing cores here to match your machine or reduce
    # if you want to save some compute cores for other tasks while training
    my_fitness_class = TASTrain()
    p_settings = PlanetSettings(size=100,
                                num_populations=4,
                                is_parallel=True,
                                cores=6,
                                verbosity=1,
                                maximize=True)

    # # USE THIS TO TEST YOUR FITNESS FUNCTION
    # print(my_fitness_class.evaluate_sample_chromosome())
    # exit()

    # USE THIS TO MAKE A NEW PLANET
    planet = Planet.default_planet(fitness_class=my_fitness_class, flags=p_settings)

    # # USE THIS TO LOAD A PLANET
    # planet = Planet.load_file(my_fitness_class, file_name+"_planet.json")

    # Train by advancing planet
    max_generations = 10000
    for idx in range(max_generations):
        planet.advance()

        # Print out status of EVE each generation
        planet.save(file_name+"_planet.json")
        planet.historian.hero.hero.save(file_name+"_hero.json")

    # NOTE: You can safely exit the python process at any time during training to stop it. The hero and planet from
    #       the last completed generation will still be saved
