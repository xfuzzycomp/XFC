# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from eve import Chromosome

from sample_trainer import TrainTAS
from kessler_game import TrainerEnvironment, KesslerGame, GraphicsType


# This script can be used to load your trainer and view the results of a saved chromosome
########################################################################################################################
realtime = True  # Whether you want to observe the loaded ai chromosome in real time
file_name = '../ai_template/trained_planets/TAS_sample_hero.json'  # The saved chromosome json file you would like to load
########################################################################################################################

chromosome = Chromosome.load_file(file_name)

# Instantiate game as visible window for viewing
settings = {
    'graphics_type': GraphicsType.Tkinter,
    'realtime_multiplier': 2, # twice realtime speed
    'perf_tracker': True,
}
game = KesslerGame(settings=settings) if realtime else TrainerEnvironment()

# Get expected fitness from saved chromosome
expected_fitness = chromosome.fitness
# Evaluate our portfolio (TASTrain) and get resultant fitness
true_fitness = TrainTAS().evaluate_scenarios(chromosome, game)

# Output results
print('Expected fitness:  ' + str(expected_fitness))
print('True fitness:  ' + str(true_fitness))
