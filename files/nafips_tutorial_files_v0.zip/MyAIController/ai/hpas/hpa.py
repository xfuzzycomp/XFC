# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from .avoidance import Avoidance
from .firing import Firing
from .aiming import Aiming
from .ship_avoidance import ShipAvoidance


class HPA:
    """
     The Purpose of HighPriorityActions is evaluate the current SituationalAwareness snapshot
    and modify Ship controls for critical scenarios including the following:
       - Aiming at targets (Aiming)
       - Firing bullets (Firing)
       - Avoiding other ships (ShipAvoidance)
       - Avoiding asteroids (Avoidance)

     The idea is that these HighPriority actions are more important than the actions assigned
    during strategy selection, and are performed last by the AI to override those previously
    scheduled control actions.
    """
    def __init__(self):
        self.aiming = Aiming()
        self.firing = Firing()
        self.ship_avoidance = ShipAvoidance()
        self.avoidance = Avoidance()


    def process(self, sa):
        """
        Call the HighPriorityAction children to modify the desired behavior of the ship based on the
        Ship's state relative to it's knowledge of the mission situation (SituationalAwareness)

        This class method activates the HPA children in order importance from lowest to highest

        Run ship through the following HPAs in the perspective order based on their priority
        """
        self.aiming.process(sa)
        self.firing.process(sa)
        self.ship_avoidance.process(sa)
        self.avoidance.process(sa)
