# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.


class Avoidance:
    """
     High priority action to avoid incoming asteroids. Generally works by assessing nearby soon-to-impact asteroids and
    avoiding the one with the soonest impact time by baking away from it.
    """

    def process(self, sa):

        # Get all asteroids with track to impact us within a certain number of time steps
        impacting_asteroids = sa.ownship.impact_less_than(2.5)

        # Don't process avoidance if no asteroids are going to hit us
        if len(impacting_asteroids) == 0:
            return None

        # Get soonest-to-impact asteroid out of nearby impacting asteroids
        else:
            min_tti = 2.51
            min_idx = 9999
            for asteroid_idx, asteroid in enumerate(impacting_asteroids):
                if asteroid.tti < min_tti:
                    min_tti = asteroid.tti
                    min_idx = asteroid_idx
            avoid_asteroid = impacting_asteroids[min_idx]

            # Just set our desired heading to match the soonest-to-impact asteroid, favoring to fly backwards away from
            # them so we can (possibly) shoot at them while backing away
            sa.desired_heading = avoid_asteroid.bearing
            sa.desired_thrust = -480
