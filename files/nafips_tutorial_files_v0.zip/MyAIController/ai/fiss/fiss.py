# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from psion import Wav, Cap, Mom
from eve import Chromosome


class FISS:
    """
    Class to store FIS and gene values for use throughout the AI
    """
    def __init__(self, chromosome: Chromosome = None):
        # Instantiate FIS and gene objects via chromosome lookup function

        # sa characteristics
        self.tti_norm_threshold = chromosome.gene("tti_norm_threshold").dna[0] * 0.5 + 0.5
        self.ast_num_norm_threshold = chromosome.gene("ast_num_norm_threshold").dna[0] * 10 + 10
        self.velocity_norm_threshold = chromosome.gene("velocity_norm_threshold").dna[0] * 50 + 50
        self.distance_norm_threshold = chromosome.gene("distance_norm_threshold").dna[0] * 100 + 100

        # strategies
        self.defensive_score_fis = Wav(chromosome.fis("defensive_score_fis").centers(), chromosome.fis("defensive_score_fis").rules())
        self.aggressive_score_fis = Wav(chromosome.fis("aggressive_score_fis").centers(), chromosome.fis("aggressive_score_fis").rules())

        # aiming
        self.aiming_fis = Wav(chromosome.fis("aiming_fis").centers(), chromosome.fis("aiming_fis").rules())

        # firing
        self.fire_bid_fis = Wav(chromosome.fis("fire_bid_fis").centers(), chromosome.fis("fire_bid_fis").rules())
