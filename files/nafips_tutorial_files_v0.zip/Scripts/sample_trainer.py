# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

import redships
# from kessler_game import Score, TrainerEnvironment
from Scenarios import example_training_portfolios as scs
from sample_controller import SampleController


class TrainTAS:
    def __init__(self):

        ##################################################################################
        # List scenarios that can be used in portfolio. Can be defined here or elsewhere #
        ##################################################################################

        scenarios = [
            scs.adv_accuracy_test_1,
            scs.adv_accuracy_test_2,
            scs.adv_accuracy_test_3,
            scs.adv_accuracy_test_4,
            scs.adv_threat_test_1,
            scs.adv_threat_test_2,
            scs.adv_threat_test_3,
            scs.adv_threat_test_4,
            scs.adv_square_1,
            scs.adv_square_2,
            scs.adv_wall_bottom_easy
        ]

        weights = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

        #####################################################################
        # Populate portfolio that will be used when training the chromosome #
        #####################################################################

        # Define portfolio (list of scenarios) with score, weighting, and controllers for each
        # scenario:  fuzzy-asteroids Scenario() object to evaluate on
        # score:  fuzzy-asteroids Score() object. Leave as None or Score() for default
        # weight:  How much to weight this scenario when calculating total score
        # controllers:  KesslerController() object (or child) used to control each ship
        # controller_chroms:  premade eve Chromosome() objects to use in each controller. Pass None to use eve training Chromosome


        # This portfolio is currently setup to train the SampleController() ai against an aggressive opponent with all
        # scenarios weighted equally. You can manually adjust your portfolio to create non-uniform weighting
        self.portfolio = [

            {'scenario': scenario,
            'weight': weight,
            'controllers': [SampleController(), redships.Aggressive()]}

            for scenario, weight in zip(scenarios, weights)]

    def evaluate_scenarios(self, chromosome, game):
        """
        Cycle through training scenario portfolio, evaluate, and apply score weighting. Return score across portfolio
        """

        # Initialize scoring values
        total_score = 0
        total_weight = 0

        for scenario in self.portfolio:

            # Set saved chromosomes for adversary and current chromosome for trainee.
            controllers = scenario['controllers']
            for controller in controllers:
                if controller.chromosome is None:
                    controller.chromosome = chromosome

            # Run game and get result
            result, perf_list = game.run(scenario=scenario['scenario'], controllers=controllers)

            ##########################################################################################
            # Calculate score for that game based on result. Refer to Kessler Score() for attributes #
            ##########################################################################################

            # Index 0 grabs score parameters from the first AI controller in the scenario
            # For adversarial self play, results from both AI could be used
            score = result.teams[0].fraction_total_asteroids_hit + result.teams[0].accuracy

            ##########################################################################################

            # Add scores and weighting to running total for use in weighted average
            total_score += score * scenario['weight']
            total_weight += scenario['weight']

        # Return score weighted average across entire portfolio
        return total_score / total_weight
