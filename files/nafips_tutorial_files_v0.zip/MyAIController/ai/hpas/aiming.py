# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

import numpy as np


class Aiming:
    """
     High priority action to trigger firing commands. Generally works by observing asteroids in a cone in front of our
    ship and determining if shooting would be beneficial or worse in the current environment and if shooting at the
    current moment would result in a hit
    """

    def process(self, sa):

        # Get relative x velocity of target asteroid relative to ownship
        relative_x_velocity = sa.ownship.target_asteroid.ship_relative_velocity[0]

        # Normalize asteroid parameters for FIS input
        norm_relative_velocity = sa.norm_speed_ast(relative_x_velocity)
        norm_dist = sa.norm_distance(sa.ownship.target_asteroid.distance)

        # Determine heading modification to aim successfully using a FIS
        heading_mod = sa.fiss.aiming_fis([norm_relative_velocity, norm_dist])

        # Modify our desired heading to incorporate aiming into movement commands
        sa.desired_heading = sa.ownship.target_asteroid.bearing + 30 * heading_mod
