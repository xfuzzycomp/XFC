# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from typing import Tuple, Dict
import numpy as np
import os
dirname = os.path.dirname(__file__)

from MyAIController.ai.strategy.selection import select_strategy
from MyAIController.ai.util.helpers import turn_rate_calc
from MyAIController.ai.util.tas_controller import TASController


class SampleController(TASController):
    """
     A very basic sample controller that just shoots at the asteroid closest to where it is already aiming
     """
    def __init__(self):
        # This is where we can set our controller to use a saved chromosome. Set to None to use eve chromosome
        self.chromosome_path = None  # We don't want to load a saved chromosome because we are training this controller
        super().__init__()

    def actions(self, ship: Dict, input_data: Dict[str, Tuple]) -> Tuple[float, float, bool]:
        self.sa.update(ship, input_data)

        # Evaluate strategy to get a target asteroid. These lines can be commented to change which action is taken
        select_strategy(self.sa)
        # defensive_action(self.sa)
        # aggressive_action(self.sa)
        # seek_and_destroy_action(self.sa)

        # If we are facing target asteroid and going slow, thrust towards it.
        target_azimuth = abs(self.sa.ownship.heading - self.sa.ownship.target_asteroid.bearing)
        if target_azimuth < 50 and self.sa.norm_speed_ship(self.sa.ownship.speed) < 0.4:
            self.sa.desired_thrust = 0.5 * ship['thrust_range'][1]
        # Otherwise if we are moving, try to stop
        elif abs(self.sa.ownship.speed) > 5:
            self.sa.desired_thrust = -np.sign(self.sa.ownship.speed) * ship['thrust_range'][1]
        # Otherwise don't thrust
        else:
            self.sa.desired_thrust = 0.0

        # High priority actions (firing, avoidance, etc)
        self.hpa.process(self.sa)

        # Apply control input based on desired settings in sa (set by actions above)
        turn_rate = turn_rate_calc(self.sa)
        thrust = self.sa.desired_thrust
        fire = True if self.sa.should_shoot else False

        return thrust, turn_rate, fire
