# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from sample_trainer import TrainTAS
from kesslergame import TrainerEnvironment
from Scenarios.example_training_portfolios import training_portfolio


def fitness_function(chromosome):

    game = TrainerEnvironment()

    controller = encode_controller(chromosome)
    controllers = [controller(),]
    for train_scenario in training_portfolio:
        result = game.run(game.run(scenario=train_scenario, controllers=controllers))
    return TrainTAS().evaluate_scenarios(chromosome, game)


if __name__ == '__main__':

    # Utilize the following to save off the hero and planet each generation
    file_name = 'trained_planets/TAS_sample'

    #  Define our fitness class object and settings for our planet. Changing cores here to match your machine or reduce
    # if you want to save some compute cores for other tasks while training
    my_fitness_class = TASTrain()
    p_settings = PlanetSettings(size=100,
                                num_populations=4,
                                is_parallel=True,
                                cores=6,
                                verbosity=1,
                                maximize=True)

    # # USE THIS TO TEST YOUR FITNESS FUNCTION
    # print(my_fitness_class.evaluate_sample_chromosome())
    # exit()

    # USE THIS TO MAKE A NEW PLANET
    planet = Planet.default_planet(fitness_class=my_fitness_class, flags=p_settings)

    # # USE THIS TO LOAD A PLANET
    # planet = Planet.load_file(my_fitness_class, file_name+"_planet.json")

    # Train by advancing planet
    max_generations = 10000
    for idx in range(max_generations):
        planet.advance()

        # Print out status of EVE each generation
        planet.save(file_name+"_planet.json")
        planet.historian.hero.hero.save(file_name+"_hero.json")

    # NOTE: You can safely exit the python process at any time during training to stop it. The hero and planet from
    #       the last completed generation will still be saved
