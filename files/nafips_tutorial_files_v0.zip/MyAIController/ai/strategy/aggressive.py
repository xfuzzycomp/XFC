# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from .seek_and_destroy import seek_and_destroy_action
from ..util.helpers import trim_angle


def aggressive_score(sa):
    """
    Return the score (from 0.0 to 1.0) for the aggressive strategy
    Generally, allows for the determination that a large asteroid near your opponent may be good to fire at
    """

    # If there are no enemy, do not act aggressive
    if len(sa.redships) < 1:
        return 0

    # Get all asteroids (size>1) within 200 units of enemy
    asteroids_near_redship = sa.redships[0].within_radius_wrap(200)
    big_asteroids_near_target = [asteroid for asteroid in asteroids_near_redship if asteroid.size > 1]

    # If there are no big asteroids near enemy, do not act aggressive
    if len(big_asteroids_near_target) == 0:
        return 0

    # Get the closest-to-enemy asteroid out of all the asteroids within radius above
    min_distance = 201.0
    for asteroid_idx, asteroid in enumerate(big_asteroids_near_target):
        if asteroid.distance_wrap < min_distance:
            min_distance = asteroid.distance_wrap

    # Normalize distance to enemy of closest-to-enemy asteroid
    norm_min_distance = min_distance / 200.0

    # Calculate normalized asteroid azimuth to enemy for use in fis input
    asteroid_direction = big_asteroids_near_target[asteroid_idx].heading
    asteroid_bearing = big_asteroids_near_target[asteroid_idx].bearing
    norm_azimuth = trim_angle(abs(asteroid_direction - asteroid_bearing)) / 180.0

    # Use a fis to determine the score of our defense strategy for use in selection
    return sa.fiss.aggressive_score_fis([norm_min_distance, norm_azimuth])


def aggressive_action(sa):
    """
    Aim at the ideal asteroid by the opponent that isn't the smallest size
    """

    # Get all asteroids (size>1) within 200 units of enemy
    asteroids_near_redship = sa.redships[0].within_radius_wrap(200)
    big_asteroids_near_target = [asteroid for asteroid in asteroids_near_redship if asteroid.size > 1]

    # Just do seek and destroy if there are no big asteroids near the enemy
    if len(big_asteroids_near_target) == 0:
        seek_and_destroy_action(sa)

    # Target closest big asteroid near the enemy
    else:
        min_distance = 201.0
        min_idx = 99
        for asteroid_idx, asteroid in enumerate(big_asteroids_near_target):
            if asteroid.distance_wrap < min_distance:
                min_distance = asteroid.distance_wrap
                min_idx = asteroid_idx

        sa.ownship.target_asteroid = big_asteroids_near_target[min_idx]
