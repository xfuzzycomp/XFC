# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from ..util.helpers import trim_angle


def seek_and_destroy_score(sa):
    """
    Return the score (from 0.0 to 1.0) for the seek_and_destroy strategy
    Generally, seeks to easily get a kill based upon the current heading of the ship
    """

    # This function is empty now ; and will always respond with a score of 0.5
    # Can be added on to for additional capability

    return 0.5


def seek_and_destroy_action(sa):
    """
    Find the asteroid that is the closest to the current heading in terms of aiming
    """

    min_aspect = 181
    min_idx = 999
    for asteroid_idx, asteroid in enumerate(sa.ownship.asteroids):
        aspect = trim_angle(asteroid.bearing - sa.ownship.heading)
        if aspect > 180.0:
            aspect -= 360.0
        elif aspect < -180:
            aspect += 360.0

        size_ratio = asteroid.size / sa.metrics.avg_asteroid_size
        if abs(aspect) < min_aspect and size_ratio < sa.size_ratio_threshold:
            min_aspect = aspect
            min_idx = asteroid_idx

    # Set found asteroid as our target asteroid
    sa.ownship.target_asteroid = sa.ownship.asteroids[min_idx]
