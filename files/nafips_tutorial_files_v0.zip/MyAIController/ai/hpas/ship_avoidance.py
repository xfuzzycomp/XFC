# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

import numpy as np


class ShipAvoidance:
    """
     High priority action to avoid crashing into enemy ships. Generally works by observing if we are too close to
    the enemy ship and backing away from them
    """

    def process(self, sa):

        if len(sa.redships) > 0:
            # Get nearest enemy ship
            nearest = None
            enemy_dist = 1e10
            for enemy in sa.redships:
                dist = np.sqrt(sum([(p1-p2)**2 for p1, p2 in zip(sa.ownship.position, enemy.position)]))
                if dist < enemy_dist:
                    nearest = enemy
                    enemy_dist = dist


            # Get distance and bearing to enemy ship
            x_dist = sa.redships[0].position[0] - sa.ownship.position[0]
            y_dist = sa.redships[0].position[1] - sa.ownship.position[1]
            enemy_bearing =  np.degrees(np.arctan2(-x_dist, y_dist))

            # If enemy ship is within a certain distance, back away from it to maintain safe distance
            if enemy_dist < 80:
                sa.should_shoot = False  # Don't shoot or we'll lose invincibility frames and die on enemy
                sa.desired_heading = enemy_bearing
                sa.desired_thrust = -480
