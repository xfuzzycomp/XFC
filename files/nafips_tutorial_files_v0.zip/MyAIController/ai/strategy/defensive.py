# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from ..util.helpers import trim_angle


def defensive_score(sa):
    """
    Return the score (from 0.0 to 1.0) for the defensive strategy
    Generally, allows for the determination that an asteroid near us may be ideal to fire at
    """

    # Get all asteroids within 300 units of us
    asteroids_near_ownship = sa.ownship.within_radius(300)

    if len(asteroids_near_ownship) == 0:
        score = 0.0

    else:
        # Get the closest asteroid out of all the asteroids within radius above
        min_distance = 101.0
        for asteroid_idx, asteroid in enumerate(asteroids_near_ownship):
            size_ratio = asteroid.size / sa.metrics.avg_asteroid_size
            if asteroid.distance < min_distance and size_ratio < sa.size_ratio_threshold:
                min_distance = asteroid.distance

        # Normalize distance of closest asteroid
        norm_min_distance = min_distance / 100.0

        # Calculate normalized azimuth for use in fis input
        asteroid_direction = asteroids_near_ownship[asteroid_idx].heading
        asteroid_bearing = asteroids_near_ownship[asteroid_idx].bearing
        norm_azimuth = trim_angle(abs(asteroid_direction - asteroid_bearing)) / 180.0

        # Use a fis to determine the score of our defense strategy for use in selection
        score = sa.fiss.defensive_score_fis([norm_min_distance, norm_azimuth])

    return score


def defensive_action(sa):
    """
    Set our target asteroid as the nearest asteroid to us. This could be improved by considering factors other
    than distance such as relative bearing to ship or asteroid time-to-impact
    """

    nearest = sa.ownship.nearest_n(1)
    if len(nearest) != 0:
        sa.ownship.target_asteroid = nearest[0]
