# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from ..util.helpers import trim_angle
import numpy as np


class Firing:
    """
     High priority action to trigger firing commands. Generally works by observing asteroids in a cone in front of our
    ship and determining if shooting would be beneficial or worse in the current environment and if shooting at the
    current moment would result in a hit
    """

    def process(self, sa):

        # Default to not shooting
        sa.should_shoot = False

        # If there are no asteroids, don't evaluate
        if len(sa.ownship.asteroids) == 0:
            return None

        # Get all asteroids within a cone in front of the ship based on asteroid size
        asteroids_in_cone = [asteroid for asteroid in sa.ownship.asteroids if abs(trim_angle(asteroid.bearing- sa.ownship.heading)) < 5 * asteroid.size + 15]
        asteroids_in_cone = sorted(asteroids_in_cone, key=lambda x: x.distance)

        # If there are no asteroids in cone, don't evaluate
        if len(asteroids_in_cone) == 0:
            return None

        # Loop asteroid list sorted by nearest assessing size and firing bid
        for idx, asteroid in enumerate(asteroids_in_cone):
            # How big is the asteroid in comparison to the average size of asteroids in existence
            size_ratio = asteroid.size / sa.metrics.avg_asteroid_size
            # If asteroid is too large, we don't want to shoot and risk hitting it, unless its our target asteroid
            if size_ratio > sa.size_ratio_threshold and asteroid is not sa.ownship.target_asteroid:
                break

            # Get relative x velocity of target asteroid relative to ownship
            relative_x_velocity = asteroid.ship_relative_velocity[0]

            # Normalize asteroid parameters for FIS input
            norm_relative_velocity = sa.norm_speed_ast(relative_x_velocity)
            norm_dist = sa.norm_distance(asteroid.distance)

            # Calculate fire bid and decide to shoot if we think we'll hit the asteroid
            fire_bid = sa.fiss.fire_bid_fis([norm_relative_velocity, norm_dist])
            if fire_bid > 0:
                sa.should_shoot = True
                break
