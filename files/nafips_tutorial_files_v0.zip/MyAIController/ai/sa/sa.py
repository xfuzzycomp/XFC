# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

import numpy as np

from .saship import SAShip, OwnShip
from ..fiss.fiss import FISS


class SA:
    """
    Situational Awareness contains state information for ownship, hostile ship(s), and the environment. It also stores
    a FISS class that holds fis objects for use by the AI
    """

    def __init__(self, chromosome=None):
        # If no chromosome has been passed to SA, do not save fis's
        if chromosome is not None:
            self.chromosome = chromosome
            self.fiss = FISS(chromosome)

        # Initiate SA properties that will be available to the AI
        self.time = 0.0
        self.ownship = OwnShip()
        self.metrics = SAMetrics()
        self.size_ratio_threshold = 2 # Used when determining whether or not we should shoot at a large asteroid

        # Desired system inputs (Set by the AI) that will be used to apply actions in the controller
        self.should_shoot = False
        self.desired_thrust = 0
        self.desired_heading = 0

    def update(self, spaceship, observation):

        # Update our ship
        self.ownship.update(observation, spaceship)

        self.redships = []
        for ship in observation['ships']:
            if ship['id'] != spaceship['id']:
                red = SAShip()
                red.update(observation, ship)
                self.redships.append(red)

        # Update metrics class
        self.metrics.update(observation, self)

        # Update sim time
        self.time = observation['time']

    ##############################################################################################
    # What follows are a series of helper functions used for normalizing values to be fis inputs #
    ##############################################################################################

    def norm_angle(self, angle):
        # normal range is (-180, 180)
        return angle / 180

    def norm_distance(self, distance):
        # normal range is (0, inf) based on fuzzy-asteroids map size
        # allow training to set normalization threshold for consistency across scenario map sizes
        max = self.fiss.distance_norm_threshold
        return distance / (max / 2) - 1

    def norm_speed_ast(self, speed):
        # normal range is (0, inf) based on momentum effects and scenario
        # allow training to set normalization threshold for consistency across scenarios
        max = self.fiss.velocity_norm_threshold
        return speed / (max / 2) - 1

    def norm_speed_ship(self, speed):
        # normal range is (-240, 240) capped by fuzzy-asteroids
        return speed / 240

    def norm_tti(self, tti):
        # normal range is (0, inf) based on speed and distance
        # allow training to set normalization threshold for consistency across scenarios
        max = self.fiss.tti_norm_threshold
        if tti is None:
            tti = max
        return tti / (max/2) - 1

    def norm_size(self, size):
        # normal range is (1, 4) capped by fuzzy-asteroids
        max = 4
        return size / (max/2) - 1

    def norm_ast_num(self, num):
        # normal range is (0, inf) based on scenario
        # allow training to set normalization threshold for consistency across scenarios
        max = self.fiss.ast_num_norm_threshold
        return num / (max/2) - 1

    ##############################################################################################


class SAMetrics:
    """
    SAMetrics stores some general observations about the environment as a whole
    """
    def __init__(self):
        # Initiate properties that will be available to the AI
        self.avg_asteroid_size = 0
        self.stddev_asteroid_size = 0
        self.avg_asteroid_speed = 0
        self.stddev_asteroid_speed = 0

    def update(self, observation, sa):
        if len(observation['asteroids']) != 0:
            self.avg_asteroid_size = np.mean([asteroid.size for asteroid in sa.ownship.asteroids])
            self.stddev_asteroid_size = np.std([asteroid.size for asteroid in sa.ownship.asteroids])
            self.avg_asteroid_speed = np.mean([asteroid.speed for asteroid in sa.ownship.asteroids])
            self.stddev_asteroid_speed = np.std([asteroid.speed for asteroid in sa.ownship.asteroids])
