# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from eve import Chromosome

from kesslergame.controller import KesslerController

from ..sa.sa import SA
from ..hpas.hpa import HPA


class TASController(KesslerController):
    """
    Thales Asteroid Smasher parent controller to handle chromosome loading into controller SA
    """
    def __init__(self):
        super().__init__()
        # Load saved chromosome for this controller. Set to none if it can't be found
        self._chromosome = None
        try:
            if self.chromosome_path is None:
                self.chromosome = None
            else:
                self.chromosome = Chromosome.load_file(self.chromosome_path)
        except AttributeError:
            self.chromosome = None
        self.hpa = HPA()


    @property
    def name(self) -> str:
        return "RedShip Controller"


    @property
    def chromosome(self):
        return self._chromosome


    @chromosome.setter
    def chromosome(self, in_chromosome):
        self._chromosome = in_chromosome
        self.sa = SA(chromosome=in_chromosome)


    def final_controller(self):
        return TASController()
