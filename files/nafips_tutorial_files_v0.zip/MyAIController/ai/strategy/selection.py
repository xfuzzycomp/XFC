# -*- coding: utf-8 -*-
# Copyright © 2019-2020 Thales Avionics USA
# NOTICE: This file is subject to the license agreement defined in file 'LICENSE', which is part of
# this source code package.

from .aggressive import aggressive_score, aggressive_action
from .defensive import defensive_score, defensive_action
from .seek_and_destroy import seek_and_destroy_score, seek_and_destroy_action


def select_strategy(sa):
    """
    Analyze the current SA state and determine which strategy should be selected at this time
    """
    # Get the scores of all strategies - commenting these out of the dictionary can de-activate them if desired
    score_dict = {
                  "aggressive": aggressive_score(sa),
                  "defensive": defensive_score(sa),
                  "seek_and_destroy": seek_and_destroy_score(sa),
                  }

    # Select the strategy with the highest score (or the first one in order, in case of a tie)
    selected_strategy = max(score_dict, key=score_dict.get)

    # Now run the selected strategy:
    if selected_strategy == "aggressive":
        aggressive_action(sa)
    elif selected_strategy == "defensive":
        defensive_action(sa)
    elif selected_strategy == "seek_and_destroy":
        seek_and_destroy_action(sa)
    else:
        print("Warning: No strategy selected")
